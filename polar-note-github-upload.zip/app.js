const STORE_KEY = "polar-note-state-v1";

const defaults = {
  baselineSleep: "23:00",
  baselineWake: "07:00",
  tolerance: 45,
  support: { name: "", phone: "" },
  entries: []
};

const labels = {
  "-3": "Đỏ: trầm cảm nặng, cần hỗ trợ",
  "-2": "Vàng: trầm cảm nhẹ, còn nhận diện được",
  "-1": "Xanh: hơi thấp nhưng vẫn hoạt động",
  "0": "Xanh: vùng hoạt động ổn định",
  "1": "Xanh: hơi cao nhưng vẫn hoạt động",
  "2": "Vàng: hưng cảm nhẹ, cần quan sát",
  "3": "Đỏ: hưng cảm nặng, cần hỗ trợ"
};

const els = {};
let state = loadState();
let selectedEnergy = 0;

document.addEventListener("DOMContentLoaded", () => {
  cacheElements();
  hydrateForms();
  wireEvents();
  render();
  refreshIcons();
});

function cacheElements() {
  [
    "todayDate",
    "stateBadge",
    "stateSummary",
    "supportDisplay",
    "callSupport",
    "textSupport",
    "editSupportBtn",
    "supportDialog",
    "supportForm",
    "supportName",
    "supportPhone",
    "checkinForm",
    "sleepTime",
    "wakeTime",
    "sleepQuality",
    "energyLabel",
    "energyOutput",
    "reflection",
    "baselineForm",
    "baselineSleep",
    "baselineWake",
    "tolerance",
    "notifyBtn",
    "alertStack",
    "trendList"
  ].forEach((id) => {
    els[id] = document.getElementById(id);
  });
}

function hydrateForms() {
  els.todayDate.textContent = new Intl.DateTimeFormat("vi-VN", {
    weekday: "short",
    day: "2-digit",
    month: "2-digit"
  }).format(new Date());

  els.baselineSleep.value = state.baselineSleep;
  els.baselineWake.value = state.baselineWake;
  els.tolerance.value = String(state.tolerance);
  els.sleepTime.value = getLastValue("sleepTime", state.baselineSleep);
  els.wakeTime.value = getLastValue("wakeTime", state.baselineWake);
  els.sleepQuality.value = getLastValue("sleepQuality", "ok");
  els.supportName.value = state.support.name;
  els.supportPhone.value = state.support.phone;
  setEnergy(getLastValue("energy", 0));
}

function wireEvents() {
  document.querySelectorAll(".energy-choice").forEach((button) => {
    button.addEventListener("click", () => setEnergy(Number(button.dataset.energy)));
  });

  els.baselineForm.addEventListener("submit", (event) => {
    event.preventDefault();
    state.baselineSleep = els.baselineSleep.value;
    state.baselineWake = els.baselineWake.value;
    state.tolerance = Number(els.tolerance.value);
    saveState();
    pushAlert("green", "Baseline đã lưu", "App sẽ dùng chuẩn mới để kiểm tra lệch giờ ngủ và giờ thức.");
    render();
  });

  els.checkinForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const entry = buildEntry();
    state.entries = [entry, ...state.entries.filter((item) => item.date !== entry.date)].slice(0, 30);
    saveState();
    const analysis = analyzeEntry(entry);
    render(analysis);
    notifyIfNeeded(analysis);
  });

  els.notifyBtn.addEventListener("click", async () => {
    if (!("Notification" in window)) {
      pushAlert("yellow", "Trình duyệt không hỗ trợ", "Bạn vẫn sẽ thấy cảnh báo trực tiếp trong app.");
      return;
    }

    const permission = await Notification.requestPermission();
    if (permission === "granted") {
      pushAlert("green", "Đã bật notification", "Khi check-in có lệch nhịp, app sẽ gửi thông báo ngay.");
    } else {
      pushAlert("yellow", "Chưa bật notification", "Cảnh báo vẫn xuất hiện trong app sau khi lưu check-in.");
    }
  });

  els.editSupportBtn.addEventListener("click", () => {
    els.supportName.value = state.support.name;
    els.supportPhone.value = state.support.phone;
    els.supportDialog.showModal();
    refreshIcons();
  });

  els.supportForm.addEventListener("submit", (event) => {
    if (event.submitter?.value === "cancel") return;
    event.preventDefault();
    state.support = {
      name: els.supportName.value.trim(),
      phone: els.supportPhone.value.trim()
    };
    saveState();
    els.supportDialog.close();
    render();
  });
}

function buildEntry() {
  const symptoms = [...document.querySelectorAll('input[name="symptoms"]:checked')].map((input) => input.value);
  return {
    date: new Date().toISOString().slice(0, 10),
    sleepTime: els.sleepTime.value,
    wakeTime: els.wakeTime.value,
    sleepQuality: els.sleepQuality.value,
    energy: selectedEnergy,
    symptoms,
    reflection: els.reflection.value.trim(),
    createdAt: new Date().toISOString()
  };
}

function analyzeEntry(entry) {
  const sleepDiff = signedClockDiff(entry.sleepTime, state.baselineSleep);
  const wakeDiff = signedClockDiff(entry.wakeTime, state.baselineWake);
  const earlyWake = wakeDiff < -state.tolerance;
  const lateWake = wakeDiff > state.tolerance;
  const earlySleep = sleepDiff < -state.tolerance;
  const lateSleep = sleepDiff > state.tolerance;
  const red = Math.abs(entry.energy) === 3 || entry.symptoms.includes("Ý nghĩ tự làm hại");
  const yellow = Math.abs(entry.energy) === 2 || earlyWake || lateWake || earlySleep || lateSleep;
  const earlyWakeStreak = countWakeStreak(entry.wakeTime, -state.tolerance);
  const highActivation = entry.energy >= 2 || (earlyWake && entry.sleepQuality === "fresh");
  const lowActivation = entry.energy <= -2 || entry.sleepQuality === "tired";

  const messages = [];
  if (earlyWake) messages.push(`Thức sớm hơn baseline ${Math.abs(wakeDiff)} phút.`);
  if (lateWake) messages.push(`Thức muộn hơn baseline ${Math.abs(wakeDiff)} phút.`);
  if (earlySleep) messages.push(`Ngủ sớm hơn baseline ${Math.abs(sleepDiff)} phút.`);
  if (lateSleep) messages.push(`Ngủ muộn hơn baseline ${Math.abs(sleepDiff)} phút.`);
  if (earlyWakeStreak >= 2) messages.push(`Thức sớm liên tục ${earlyWakeStreak} ngày.`);
  if (highActivation) messages.push("Dành một phút kiểm tra: có hy vọng mới, ý tưởng mới, chất kích thích, ít ngủ nhưng khỏe bất thường không?");
  if (lowActivation) messages.push("Kiểm tra mức thu mình, vô vọng, kiệt sức và cân nhắc báo cho người hỗ trợ.");
  if (red) messages.push("Vùng đỏ: ưu tiên liên hệ người hỗ trợ hoặc chuyên gia đang theo dõi bạn.");

  return {
    level: red ? "red" : yellow ? "yellow" : "green",
    title: red ? "Cần hỗ trợ" : yellow ? "Có lệch nhịp cần chú ý" : "Trong vùng ổn định",
    messages
  };
}

function render(analysis = analyzeEntry(state.entries[0] || sampleEntry())) {
  renderSupport();
  renderTrend();
  renderState(analysis);
  if (state.entries[0]) renderAlerts(analysis);
  refreshIcons();
}

function renderState(analysis) {
  els.stateBadge.className = `state-badge state-${analysis.level}`;
  const badgeText = analysis.level === "green" ? "Vùng xanh" : analysis.level === "yellow" ? "Vùng vàng" : "Vùng đỏ";
  els.stateBadge.innerHTML = `<span class="dot"></span>${badgeText}`;
  els.stateSummary.textContent = analysis.messages[0] || "Giấc ngủ và năng lượng đang nằm trong chuẩn cá nhân.";
}

function renderAlerts(analysis) {
  els.alertStack.innerHTML = "";
  if (!analysis.messages.length) return;
  const icon = analysis.level === "red" ? "siren" : analysis.level === "yellow" ? "triangle-alert" : "circle-check";
  pushAlert(analysis.level, analysis.title, analysis.messages.join(" "), icon, false);
}

function pushAlert(level, title, message, icon = "info", prepend = true) {
  const node = document.createElement("div");
  node.className = `alert ${level}`;
  node.innerHTML = `
    <i data-lucide="${icon}"></i>
    <div>
      <strong>${title}</strong>
      <p>${message}</p>
    </div>
  `;
  if (prepend) {
    els.alertStack.prepend(node);
  } else {
    els.alertStack.append(node);
  }
  refreshIcons();
}

function refreshIcons() {
  if (window.lucide) {
    window.lucide.createIcons();
  }
}

function renderSupport() {
  const { name, phone } = state.support;
  if (!name && !phone) {
    els.supportDisplay.textContent = "Chưa đặt liên hệ.";
    els.callSupport.classList.add("disabled");
    els.textSupport.classList.add("disabled");
    els.callSupport.href = "#";
    els.textSupport.href = "#";
    return;
  }

  els.supportDisplay.textContent = [name, phone].filter(Boolean).join(" · ");
  els.callSupport.classList.toggle("disabled", !phone);
  els.textSupport.classList.toggle("disabled", !phone);
  els.callSupport.href = phone ? `tel:${phone}` : "#";
  els.textSupport.href = phone
    ? `sms:${phone}?&body=${encodeURIComponent("Mình đang ở vùng đỏ/vàng trong Polar Note. Bạn có thể kiểm tra giúp mình không?")}`
    : "#";
}

function renderTrend() {
  const entries = state.entries.slice(0, 7);
  if (!entries.length) {
    els.trendList.innerHTML = `<p class="muted">Chưa có dữ liệu. Check-in hôm nay sẽ tạo dòng đầu tiên.</p>`;
    return;
  }

  els.trendList.innerHTML = entries.map((entry) => {
    const level = Math.abs(entry.energy) === 3 ? "red" : Math.abs(entry.energy) === 2 ? "yellow" : "green";
    const color = level === "red" ? "var(--red)" : level === "yellow" ? "var(--yellow)" : "var(--green)";
    const width = `${Math.max(8, Math.abs(entry.energy) * 16 + 8)}%`;
    const offset = entry.energy < 0 ? "-100%" : "0";
    const sleepDuration = formatDuration(minutesBetween(entry.sleepTime, entry.wakeTime));
    return `
      <div class="trend-item">
        <span class="trend-date">${formatDate(entry.date)}</span>
        <div class="trend-bars">
          <div class="bar" aria-label="Năng lượng ${entry.energy}">
            <span style="--bar-width:${width}; --bar-offset:${offset}; --bar-color:${color}"></span>
          </div>
          <p class="muted">${entry.sleepTime} - ${entry.wakeTime} · ${sleepDuration}</p>
        </div>
        <span class="trend-chip state-${level}">${entry.energy > 0 ? "+" : ""}${entry.energy}</span>
      </div>
    `;
  }).join("");
}

function setEnergy(value) {
  selectedEnergy = Number(value);
  document.querySelectorAll(".energy-choice").forEach((button) => {
    const active = Number(button.dataset.energy) === selectedEnergy;
    button.classList.toggle("active", active);
    button.setAttribute("aria-checked", String(active));
  });
  els.energyLabel.textContent = labels[String(selectedEnergy)];
  els.energyOutput.textContent = selectedEnergy > 0 ? `+${selectedEnergy}` : String(selectedEnergy);
  const level = Math.abs(selectedEnergy) === 3 ? "red" : Math.abs(selectedEnergy) === 2 ? "yellow" : "green";
  els.energyOutput.style.background = `var(--${level})`;
}

function notifyIfNeeded(analysis) {
  if (analysis.level === "green") return;
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  new Notification(`Polar Note: ${analysis.title}`, {
    body: analysis.messages.slice(0, 2).join(" "),
    icon: "assets/rhythm-waves.png"
  });
}

function signedClockDiff(value, baseline) {
  const valueMinutes = toMinutes(value);
  const baselineMinutes = toMinutes(baseline);
  let diff = valueMinutes - baselineMinutes;
  if (diff > 720) diff -= 1440;
  if (diff < -720) diff += 1440;
  return diff;
}

function minutesBetween(start, end) {
  const startMinutes = toMinutes(start);
  const endMinutes = toMinutes(end);
  return endMinutes >= startMinutes ? endMinutes - startMinutes : endMinutes + 1440 - startMinutes;
}

function toMinutes(time) {
  const [hours, minutes] = time.split(":").map(Number);
  return hours * 60 + minutes;
}

function formatDuration(totalMinutes) {
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return minutes ? `${hours}h ${minutes}m` : `${hours}h`;
}

function countWakeStreak(wakeTime, threshold) {
  let streak = 0;
  for (const entry of state.entries) {
    const diff = signedClockDiff(entry.wakeTime, state.baselineWake);
    if (diff < threshold) streak += 1;
    else break;
  }
  return streak;
}

function formatDate(date) {
  return new Intl.DateTimeFormat("vi-VN", { day: "2-digit", month: "2-digit" }).format(new Date(`${date}T12:00:00`));
}

function getLastValue(key, fallback) {
  return state.entries[0]?.[key] ?? fallback;
}

function sampleEntry() {
  return {
    date: new Date().toISOString().slice(0, 10),
    sleepTime: state.baselineSleep,
    wakeTime: state.baselineWake,
    sleepQuality: "ok",
    energy: 0,
    symptoms: []
  };
}

function loadState() {
  try {
    return { ...defaults, ...JSON.parse(localStorage.getItem(STORE_KEY)) };
  } catch {
    return defaults;
  }
}

function saveState() {
  localStorage.setItem(STORE_KEY, JSON.stringify(state));
}
