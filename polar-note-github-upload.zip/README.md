# Polar Note

Polar Note is a lightweight bipolar mood and sleep tracking prototype built with plain HTML, CSS, and JavaScript.

## Features

- Personal sleep baseline with configurable deviation threshold.
- Daily sleep check-in: sleep time, wake time, sleep quality.
- Energy scale from `-3` to `+3` with green, yellow, and red zones.
- Optional symptom checklist for manic and depressive signs.
- Reflection prompt for possible triggers such as new hope, new ideas, stimulants, stress, or medication changes.
- Support contact with call and SMS actions.
- Local browser storage through `localStorage`.
- Optional browser notifications after permission is granted.

## Run Locally

Open `index.html` directly in a browser.

## Deploy To Vercel

This is a static site. In Vercel, use:

- Framework Preset: `Other`
- Build Command: leave empty
- Output Directory: `.`

## Privacy Note

This prototype stores check-in data only in the user's browser. It does not sync data to a server.
